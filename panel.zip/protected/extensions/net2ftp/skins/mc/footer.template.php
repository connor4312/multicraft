<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<!-- Template /skins/mc/footer.php begin -->
</div>
<br>
<!-- Template /skins/mc/footer.php end -->
