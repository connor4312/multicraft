<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2009 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function getSkinArray() {

// --------------
// This function returns an array of skin names, file names, ...
// --------------

	global $net2ftp_globals;

// -------------------------------------------------------------------------
// Blue
// -------------------------------------------------------------------------
	$skinArray["mc"]["name"]             = __("Blue");
	$skinArray["mc"]["iconset"]          = "nuvola";
	$skinArray["mc"]["image_url"]        = $net2ftp_globals["application_rootdir_url"] . "/img/net2ftp";
	$skinArray["mc"]["icon_size_mime"]   = "16";

	return $skinArray;

} // End function getSkinArray

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **
function printSkinSelect($fieldname, $onchange, $style, $class) {


// --------------
// This function prints a select with the available skins
// Skin nr 1 is the default skin
// --------------

	global $net2ftp_globals;
	$skinArray = getSkinArray();

	if     ($net2ftp_globals["skin"] != "")        { $currentskin = $net2ftp_globals["skin"]; }
	elseif ($net2ftp_globals["cookie_skin"] != "") { $currentskin = $net2ftp_globals["cookie_skin"]; }
	else                                           { $currentskin = "mc"; }

	if ($onchange == "") { $onchange_full = ""; }
	else                 { $onchange_full = "onchange=\"$onchange\""; }

	if ($style == "")    { $style_full = ""; }
	else                 { $style_full = "style=\"$style\""; }

	if ($class == "")    { $class_full = ""; }
	else                 { $class_full = "class=\"$class\""; }

	echo "<select name=\"$fieldname\" id=\"$fieldname\" $onchange_full $style_full $class_full>\n";

	while (list($key,$value) = each($skinArray)) {
	// $key loops over "blue", "pastel", ...
	// $value will be an array like $value["name"] = "Blue"
		if ($key == $currentskin) { $selected = "selected=\"selected\""; }
		else                      { $selected = ""; }
		echo "<option value=\"" . $key . "\" $selected>" . $value["name"] . "</option>\n";
	} // end while

	echo "</select>\n";

} // End function printSkinSelect

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function getMime($listline) {

// --------------
// Checks the extension of a file to determine which is the type of the file and the icon
// --------------

// -------------------------------------------------------------------------
// Global variables and settings
// -------------------------------------------------------------------------
	global $net2ftp_globals, $net2ftp_settings;
	$skinArray = getSkinArray();

	if     ($listline["dirorfile"] == "d") { $last = "directory"; }
	elseif ($listline["dirorfile"] == "l") { $last = "symlink"; }
	else                                   { $last = get_filename_extension($listline["dirfilename"]); }

// -------------------------------------------------------------------------
// Icon names
// -------------------------------------------------------------------------
	if ($last == "directory") {
		$icon = "fa fa-folder";
		$type = __("Directory");
	}
	elseif ($last == "symlink") {
		$icon = "fa fa-link";
		$type = __("Symlink");
	}

// Web files
	elseif ($last == "asp") {
		$icon = "icon icon-file-code";
		$type = __("ASP script");
	}
	elseif ($last == "css") {
		$icon = "icon icon-file-code";
		$type = __("Cascading Style Sheet");
	}
	elseif ($last == "htm" || $last == "html") {
		$icon = "icon icon-file-code";
		$type = __("HTML file");
	}
	elseif ($last == "java") {
		$icon = "icon icon-file-code";
		$type = __("Java source file");
	}
	elseif ($last == "js") {
		$icon = "icon icon-file-code";
		$type = __("JavaScript file");
	}
	elseif ($last == "phps") {
		$icon = "icon icon-file-code";
		$type = __("PHP Source");
	}
	elseif (substr($last,0,3) == "php") {
		$icon = "icon icon-file-code";
		$type = __("PHP script");
	}
	elseif ($last == "txt") {
		$icon = "icon icon-file-default";
		$type = __("Text file");
	}

// Images
	elseif ($last == "bmp") {
		$icon = "icon icon-file-graphic";
		$type = __("Bitmap file");
	}
	elseif ($last == "gif") {
		$icon = "icon icon-file-graphic";
		$type = __("GIF file");
	}
	elseif ($last == "jpg" || $last == "jpeg") {
		$icon = "icon icon-file-graphic";
		$type = __("JPEG file");
	}
	elseif ($last == "png") {
		$icon = "icon icon-file-graphic";
		$type = __("PNG file");
	}
	elseif ($last == "tif" || $last == "tiff") {
		$icon = "icon icon-file-graphic";
		$type = __("TIF file");
	}
	elseif ($last == "xcf") {
		$icon = "icon icon-file-graphic";
		$type = __("GIMP file");
	}

// Executables and scripts
	elseif ($last == "exe" || $last == "com") {
		$icon = "icon icon-file-default";
		$type = __("Executable");
	}
	elseif ($last == "sh") {
		$icon = "icon icon-file-default";
		$type = __("Shell script");
	}

// MS Office
	elseif ($last == "doc") {
		$icon = "icon icon-file-work";
		$type = __("MS Office - Word document");
	}
	elseif ($last == "xls") {
		$icon = "icon icon-file-excel";
		$type = __("MS Office - Excel spreadsheet");
	}
	elseif ($last == "ppt") {
		$icon = "icon icon-file-graphic";
		$type = __("MS Office - PowerPoint presentation");
	}
	elseif ($last == "mdb") {
		$icon = "icon icon-file-default";
		$type = __("MS Office - Access database");
	}
	elseif ($last == "vsd") {
		$icon = "icon icon-file-default";
		$type = __("MS Office - Visio drawing");
	}
	elseif ($last == "mpp") {
		$icon = "icon icon-file-default";
		$type = __("MS Office - Project file");
	}

// OpenOffice 6
	elseif ($last == "sxw") {
		$icon = "icon icon-file-office";
		$type = __("OpenOffice - Writer 6.0 document");
	}
	elseif ($last == "stw") {
		$icon = "icon icon-file-office";
		$type = __("OpenOffice - Writer 6.0 template");
	}
	elseif ($last == "sxc") {
		$icon = "icon icon-file-office";
		$type = __("OpenOffice - Calc 6.0 spreadsheet");
	}
	elseif ($last == "stc") {
		$icon = "icon icon-file-office";
		$type = __("OpenOffice - Calc 6.0 template");
	}
	elseif ($last == "sxd") {
		$icon = "icon icon-file-office";
		$type = __("OpenOffice - Draw 6.0 document");
	}
	elseif ($last == "std") {
		$icon = "icon icon-file-office";
		$type = __("OpenOffice - Draw 6.0 template");
	}
	elseif ($last == "sxi") {
		$icon = "icon icon-file-office";
		$type = __("OpenOffice - Impress 6.0 presentation");
	}
	elseif ($last == "sti") {
		$icon = "icon icon-file-office";
		$type = __("OpenOffice - Impress 6.0 template");
	}
	elseif ($last == "sxg") {
		$icon = "icon icon-file-office";
		$type = __("OpenOffice - Writer 6.0 global document");
	}
	elseif ($last == "sxm") {
		$icon = "icon icon-file-office";
		$type = __("OpenOffice - Math 6.0 document");
	}

// StarOffice 5
	elseif ($last == "sdw") {
		$icon = "icon icon-file-office";
		$type = __("StarOffice - StarWriter 5.x document");
	}
	elseif ($last == "sgl") {
		$icon = "icon icon-file-office";
		$type = __("StarOffice - StarWriter 5.x global document");
	}
	elseif ($last == "sdc") {
		$icon = "icon icon-file-office";
		$type = __("StarOffice - StarCalc 5.x spreadsheet");
	}
	elseif ($last == "sda") {
		$icon = "icon icon-file-office";
		$type = __("StarOffice - StarDraw 5.x document");
	}
	elseif ($last == "sdd") {
		$icon = "icon icon-file-office";
		$type = __("StarOffice - StarImpress 5.x presentation");
	}
	elseif ($last == "sdp") {
		$icon = "icon icon-file-office";
		$type = __("StarOffice - StarImpress Packed 5.x file");
	}
	elseif ($last == "smf") {
		$icon = "icon icon-file-office";
		$type = __("StarOffice - StarMath 5.x document");
	}
	elseif ($last == "sds") {
		$icon = "icon icon-file-office";
		$type = __("StarOffice - StarChart 5.x document");
	}
	elseif ($last == "sdm") {
		$icon = "icon icon-file-office";
		$type = __("StarOffice - StarMail 5.x mail file");
	}

// PDF and PS
	elseif ($last == "pdf") {
		$icon = "icon icon-file-pdf";
		$type = __("Adobe Acrobat document");
	}

// Archives
	elseif ($last == "arc") {
		$icon = "icon icon-file-archive";
		$type = __("ARC archive");
	}
	elseif ($last == "arj") {
		$icon = "icon icon-file-archive";
		$type = __("ARJ archive");
	}
	elseif ($last == "rpm") {
		$icon = "rpm";
		$type = __("RPM");
	}
	elseif ($last == "gz") {
		$icon = "icon icon-file-archive";
		$type = __("GZ archive");
	}
	elseif ($last == "tar") {
		$icon = "tar";
		$type = __("TAR archive");
	}
	elseif ($last == "zip") {
		$icon = "icon icon-file-archive";
		$type = __("Zip archive");
	}

// Movies
	elseif ($last == "mov") {
		$icon = "icon icon-file-graphic";
		$type = __("MOV movie file");
	}
	elseif ($last == "mpg" || $last == "mpeg") {
		$icon = "icon icon-file-graphic";
		$type = __("MPEG movie file");
	}
	elseif ($last == "rm" || $last == "ram") {
		$icon = "icon icon-file-graphic";
		$type = __("Real movie file");
	}
	elseif ($last == "qt") {
		$icon = "icon icon-file-graphic";
		$type = __("Quicktime movie file");
	}

// Flash
	elseif ($last == "fla") {
		$icon = "icon icon-file-graphic";
		$type = __("Shockwave flash file");
	}
	elseif ($last == "swf") {
		$icon = "icon icon-file-graphic";
		$type = __("Shockwave file");
	}


// Sound
	elseif ($last == "wav") {
		$icon = "icon icon-file-default";
		$type = __("WAV sound file");
	}

// Fonts
	elseif ($last == "ttf") {
		$icon = "icon icon-file-default";
		$type = __("Font file");
	}

// Default Extension
	elseif ($last) {
		$icon = "icon icon-file-default";
		$type = Yii::t('mc', "{file} File", array('{file}'=>strtoupper($last)));
	}

// Default File
	else {
		$icon = "icon icon-file-default";
		$type = __("File");
	}

	if ($icon == "") { $icon = "icon icon-file-default"; }
	if ($type == "") { $type = __("File"); }

// -------------------------------------------------------------------------
// Return mime icon and mime type
// -------------------------------------------------------------------------

	$mime["mime_icon"] = '<i class="' . $icon . '"></i>';
	$mime["mime_type"] = $type;

	return $mime;

} // end getMime

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printMime($what, $listline) {

// --------------
// Prints the Mime icon
// --------------

	$mime = getMime($listline);

	if     ($what == "icon") {
		echo $mime["mime_icon"];
	}
	elseif ($what == "type") {
		echo $mime["mime_type"];
	}

} // end printMimeIcon

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printActionIcon($action, $onclick, $unused = '', $a = false) {

// --------------
// Checks the icon related to an action
// --------------

// -------------------------------------------------------------------------
// Global variables and settings
// -------------------------------------------------------------------------
	global $net2ftp_globals, $net2ftp_settings;
	$skinArray = getSkinArray();

// -------------------------------------------------------------------------
// Icon name
// -------------------------------------------------------------------------
	if ($action == "back") {
		$alt = __("Back");
		$icon = "fa fa-chevron-left";
		$accesskey = "b";
	}
	elseif ($action == "forward") {
		$alt = __("Submit");
		$icon = "fa fa-check";
		$accesskey = "v";
	}
	elseif ($action == "refresh") {
		$alt = __("Refresh");
		$icon = "fa fa-refresh";
		$accesskey = "r";
	}
	elseif ($action == "view_details") {
		$alt = __("Details");
		$icon = "fa fa-list";
		$accesskey = "";
	}
	elseif ($action == "view_icons") {
		$alt = __("Icons");
		$icon = "fa fa-star";
		$accesskey = "";
	}
	elseif ($action == "listdirectories") {
		$alt = __("List");
		$icon = "fa fa-list";
		$accesskey = "";
	}
	elseif ($action == "logout") {
		$alt = __("Logout");
		$icon = "fa fa-sign-out";
		$accesskey = "l";
	}
	elseif ($action == "help") {
		$alt = __("Help");
		$icon = "fa fa-question";
		$accesskey = "i";
	}
	elseif ($action == "bookmark") {
		$alt = __("Bookmark");
		$icon = "fa fa-bookmark";
		$accesskey = "h";
	}
	elseif ($action == "save") {
		$alt = __("Save");
		$icon = "fa fa-floppy-o";
		$accesskey = "s";
	}
	elseif ($action == "up") {
		$alt = __("Up");
		$icon = "fa fa-chevron-up";
		$accesskey = "u";
	}
	else {
		$alt = __("Default");
		$icon = "icon icon-file-default";
		$accesskey = "";
	}

	if (false && $accesskey != "") { 
		$alt = $alt . " (accesskey $accesskey)";
		$accesskeytag = "accesskey=\"$accesskey\"" ; 
	}
	else {
		$accesskeytag = "";
	}

// -------------------------------------------------------------------------
// Icon directory
// -------------------------------------------------------------------------
	$icon_directory = $skinArray[$net2ftp_globals["skin"]]["image_url"] . "/actions";

// -------------------------------------------------------------------------
// URL
// Do not include a URL if $onclick is empty
// -------------------------------------------------------------------------

	$icon_total = '<i class="' . $icon . '"></i>' ;

    if (!$a)
    {
        echo '<button onclick="'.$onclick.'; return false" class="btn" />'. $icon_total . ' ' . $alt.'</button>';
        return;
    }

	if ($onclick != "") { 
		$href_start = "<a href=\"javascript:$onclick\" title=\"$alt\" $accesskeytag>"; 
		$href_end   = "</a>";
	}
	else {
		$href_start = ""; 
		$href_end   = "";
	}

    echo $href_start.$icon_total.' '.$alt.$href_end;
    return;

// -------------------------------------------------------------------------
// Return text (for mobile skin) or icon (for all other skins)
// -------------------------------------------------------------------------


	echo $icon_total;


/* -------------------------------------------------------------------------

---------------------------
  Accesskey documentation
---------------------------

Tutorial
http://www.cs.tut.fi/~jkorpela/forms/accesskey.html
ALT-A and ALT-F may not be used on IE

Login page
---------------------------
l login

Logout page
---------------------------
l link to login page

Browse page
---------------------------
See icons above.
Used: b, v, r, l, i, h, s

g directory textbox

Actions
w new dir
y new file
e install template
u upload, up
n advanced
c copy
m move
d delete
o rename
p chmod
x download
z zip
q size
j search

Headers
k up
t all

Items
1 item 1
2 item 2
...
9 item 9


------------------------------------------------------------------------- */

} // end printActionIcon

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************







// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printModeIcon($setting, $on_off, $onclick) {

// --------------
// Checks the icon related to a mode
// --------------

// -------------------------------------------------------------------------
// Global variables and settings
// -------------------------------------------------------------------------
	global $net2ftp_globals, $net2ftp_settings;

	if ($setting == "details") {
		$alt = __("Details");
		$icon = "view_detailed";
	}
	elseif ($setting == "icons") {
		$alt = __("Icons");
		$icon = "view_icon";
	}

// Default
	else {
		$alt = __("Default");
		$icon = "mime";
	}

// Default
	if ($alt  == "") { $alt  = "Default"; }
	if ($icon == "") { $icon = "mime"; }

// On or off: icon and style
	if ($on_off == "on") {
		$icon_normal      = $icon;
		$icon_onmouseover = $icon;
	}
	else {
		$icon_normal      = $icon . "_light";
		$icon_onmouseover = $icon;
	}

// -------------------------------------------------------------------------
// Icon directory
// -------------------------------------------------------------------------
	$icon_directory = $skinArray[$net2ftp_globals["skin"]]["image_url"] . "/settings";

// -------------------------------------------------------------------------
// Return icon
// -------------------------------------------------------------------------

// DO NOT CLOSE THE IMAGE TAG TO ALLOW ADDITIONAL ACTIONS
	if ($on_off == "on") {
		if ($net2ftp_settings["fix_png"] == "yes" && $net2ftp_globals["browser_agent"] == "IE" && $net2ftp_globals["browser_platform"] == "Win" && ($net2ftp_globals["browser_version"] == "5.5" || $net2ftp_globals["browser_version"] == "6.0" || $net2ftp_globals["browser_version"] == "7.0")) { 
			$icon_total = "<img src=\"$icon_directory/spacer.gif\"   alt=\"$alt\" style=\"border: 2px solid #000000; padding-top: 1px; padding-left: 2px; width: 32px; height: 32px; vertical-align: middle; filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='$icon_directory/$icon', sizingMethod='scale');\" />\n"; 
		}
		else {
			$icon_total = "<img src=\"$icon_directory/$icon_normal\" alt=\"$alt\" style=\"border: 2px solid #000000; padding-top: 1px; padding-left: 2px; width: 32px; height: 32px; vertical-align: middle;\" />\n"; 
		}
	}
	else {
		if ($net2ftp_settings["fix_png"] == "yes" && $net2ftp_globals["browser_agent"] == "IE" && $net2ftp_globals["browser_platform"] == "Win" && ($net2ftp_globals["browser_version"] == "5.5" || $net2ftp_globals["browser_version"] == "6.0" || $net2ftp_globals["browser_version"] == "7.0")) {
			$icon_total = "<a href=\"javascript:$onClick\"><img src=\"$icon_directory/spacer.gif\"   alt=\"$alt\" onmouseover=\"this.style.margin='0px';this.style.width='34px';this.style.height='34px';\" onmouseout=\"this.style.margin='1px';this.style.width='32px';this.style.height='32px';\" style=\"border: 0px; margin: 1px; width: 32px; height: 32px; vertical-align: middle; filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='$icon_directory/$icon', sizingMethod='scale');\" /></a>\n"; 
		}
		else { 
			$icon_total = "<a href=\"javascript:$onClick\" title=\"$alt\"><img src=\"$icon_directory/$icon_normal\" alt=\"$alt\" onmouseover=\"this.style.margin='0px';this.style.width='34px';this.style.height='34px';\" onmouseout=\"this.style.margin='1px';this.style.width='32px';this.style.height='32px';\" style=\"border: 0px; margin: 1px; width: 32px; height: 32px; vertical-align: middle;\" /></a>\n"; 
		}
	}

	return $icon_total;

} // end printModeIcon

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************







// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printTitleIcon() {

// --------------
// This function returns the title icon based on the $state and $state2 variables
// --------------

// -------------------------------------------------------------------------
// Global variables and settings
// -------------------------------------------------------------------------
	global $net2ftp_globals, $net2ftp_settings;
	$skinArray = getSkinArray();
	
// -------------------------------------------------------------------------
// Icon names
// -------------------------------------------------------------------------
	if     ($net2ftp_globals["state"] == "admin" || $net2ftp_globals["state"] == "admin_createtables" || $net2ftp_globals["state"] == "admin_emptylogs" || $net2ftp_globals["state"] == "admin_viewlogs") {
		$icon = "kcontrol";
	}
	elseif ($net2ftp_globals["state"] == "advanced" || $net2ftp_globals["state"] == "advanced_ftpserver" || $net2ftp_globals["state"] == "advanced_parsing" || $net2ftp_globals["state"] == "advanced_webserver") {
		$icon = "misc";
	}
	elseif ($net2ftp_globals["state"] == "bookmark") {
		$icon = "bookmark";
	}
	elseif ($net2ftp_globals["state"] == "calculatesize") {
		$icon = "";
	}
	elseif ($net2ftp_globals["state"] == "chmod") {
		$icon = "kgpg_info";
	}
	elseif ($net2ftp_globals["state"] == "copymovedelete") {
		if     ($net2ftp_globals["state2"] == "copy")   { $icon = "editcopy"; }
		elseif ($net2ftp_globals["state2"] == "move")   { $icon = "editcut"; }
		elseif ($net2ftp_globals["state2"] == "delete") { $icon = "edittrash"; }
	}
	elseif ($net2ftp_globals["state"] == "easywebsite") {
		$icon = "colorize";
	}
	elseif ($net2ftp_globals["state"] == "edit") {
		$icon = "package_editors";
	}
	elseif ($net2ftp_globals["state"] == "findstring") {
		$icon = "viewmag";
	}
	elseif ($net2ftp_globals["state"] == "jupload" || $net2ftp_globals["state"] == "upload") {
		$icon = "konquest";
	}
	elseif ($net2ftp_globals["state"] == "login" || $net2ftp_globals["state"] == "login_small") {
		$icon = "kgpg_identity";
	}
	elseif ($net2ftp_globals["state"] == "newdir") {
		$icon = "folder_new";
	}
	elseif ($net2ftp_globals["state"] == "rename") {
		$icon = "folder_txt";
	}
	elseif ($net2ftp_globals["state"] == "updatefile") {
		$icon = "view_left_right";
	}
	elseif ($net2ftp_globals["state"] == "view") {
		if     ($net2ftp_globals["state2"] == "image") { $icon = "thumbnail"; }
		elseif ($net2ftp_globals["state2"] == "flash") { $icon = "aktion"; }
		elseif ($net2ftp_globals["state2"] == "text")  { $icon = "terminal"; }
	}
	elseif ($net2ftp_globals["state"] == "zip") {
		$icon = "ark";
	}

// Default File
	else {
		$icon = "misc";
	}

	if ($icon == "") { $icon = "misc"; }

// -------------------------------------------------------------------------
// Return title icon
// -------------------------------------------------------------------------
	$icon .= ".png";
	$icon_directory = $skinArray[$net2ftp_globals["skin"]]["image_url"] . "/titles";
	
	// Internet Explorer does not display transparent PNG images correctly.
	// A solution is described here: http://support.microsoft.com/default.aspx?scid=kb;en-us;Q294714
	if ($net2ftp_settings["fix_png"] == "yes" && $net2ftp_globals["browser_agent"] == "IE" && $net2ftp_globals["browser_platform"] == "Win" && ($net2ftp_globals["browser_version"] == "5.5" || $net2ftp_globals["browser_version"] == "6.0" || $net2ftp_globals["browser_version"] == "7.0")) { 
		$icon_total = "<img src=\"$icon_directory/spacer.gif\" alt=\"icon\" style=\"width: 48px; height: 48px; vertical-align: middle; filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='$icon_directory/$icon', sizingMethod='scale')\" />\n"; 
	}
	else { 
		$icon_total = "<img src=\"$icon_directory/$icon\"      alt=\"icon\" style=\"width: 48px; height: 48px; vertical-align: middle;\" />\n"; 
	}

	echo $icon_total;

} // end printTitleIcon

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************



// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printPngImage($src, $alt, $style) {

// --------------
// This function prints a .png image with or without the fix for IE
// Prerequisite: spacer.gif must exist in the same directory as the image
// --------------

// -------------------------------------------------------------------------
// Global variables and settings
// -------------------------------------------------------------------------
	global $net2ftp_globals, $net2ftp_settings;

// -------------------------------------------------------------------------
// Calculate the src of spacer.gif
// -------------------------------------------------------------------------
	$last_slash_position = strrpos($src, "/");
	if ($last_slash_position === false) { $src_spacer = "spacer.gif"; }
	else { 
		$src_spacer = substr($src, 0, $last_slash_position+1) . "spacer.gif";
	}

// -------------------------------------------------------------------------
// Form the HTML
// -------------------------------------------------------------------------

	// Internet Explorer does not display transparent PNG images correctly.
	// A solution is described here: http://support.microsoft.com/default.aspx?scid=kb;en-us;Q294714
	if ($net2ftp_settings["fix_png"] == "yes" && $net2ftp_globals["browser_agent"] == "IE" && $net2ftp_globals["browser_platform"] == "Win" && ($net2ftp_globals["browser_version"] == "5.5" || $net2ftp_globals["browser_version"] == "6.0" || $net2ftp_globals["browser_version"] == "7.0")) { 
		$image = "<img src=\"$src_spacer\" alt=\"$alt\" style=\"$style; filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='$src', sizingMethod='scale')\" />\n"; 
	}
	else { 
		$image = "<img src=\"$src\" alt=\"$alt\" style=\"$style\" />\n"; 
	}

	echo $image;

} // end printPngImage

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************


?>
