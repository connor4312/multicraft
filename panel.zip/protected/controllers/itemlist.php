<?php
/**
 *
 *   Copyright © 2010-2012 by xhost.ch GmbH
 *
 *   All rights reserved.
 *
 **/

$itemlist = array();
$itemlist[] = 
  array (
    'item' => 260,
    'name' => 'Apple',
  );
$itemlist[] = 
  array (
    'item' => 262,
    'name' => 'Arrow',
  );
$itemlist[] = 
  array (
    'item' => 355,
    'name' => 'Bed',
  );
$itemlist[] = 
  array (
    'item' => 7,
    'name' => 'Bedrock',
  );
$itemlist[] = 
  array (
    'item' => 369,
    'name' => 'Blaze Rod',
  );
$itemlist[] = 
  array (
    'item' => 377,
    'name' => 'Blaze Powder',
  );
$itemlist[] = 
  array (
    'item' => 333,
    'name' => 'Boat',
  );
$itemlist[] = 
  array (
    'item' => 352,
    'name' => 'Bone',
  );
$itemlist[] = 
  array (
    'item' => 340,
    'name' => 'Book',
  );
$itemlist[] = 
  array (
    'item' => 47,
    'name' => 'Bookshelf',
  );
$itemlist[] = 
  array (
    'item' => 261,
    'name' => 'Bow',
  );
$itemlist[] = 
  array (
    'item' => 281,
    'name' => 'Bowl',
  );
$itemlist[] = 
  array (
    'item' => 297,
    'name' => 'Bread',
  );
$itemlist[] = 
  array (
    'item' => 379,
    'name' => 'Brewing Stand',
  );
$itemlist[] = 
  array (
    'item' => 45,
    'name' => 'Brick Block',
  );
$itemlist[] = 
  array (
    'item' => 108,
    'name' => 'Brick Stairs',
  );
$itemlist[] = 
  array (
    'item' => 39,
    'name' => 'Brown Mushroom',
  );
$itemlist[] = 
  array (
    'item' => 325,
    'name' => 'Bucket',
  );
$itemlist[] = 
  array (
    'item' => 62,
    'name' => 'Burning Furnace',
  );
$itemlist[] = 
  array (
    'item' => 81,
    'name' => 'Cactus',
  );
$itemlist[] = 
  array (
    'item' => 354,
    'name' => 'Cake',
  );
$itemlist[] = 
  array (
    'item' => 92,
    'name' => 'Cake Block',
  );
$itemlist[] = 
  array (
    'item' => 380,
    'name' => 'Cauldron',
  );
$itemlist[] = 
  array (
    'item' => 305,
    'name' => 'Chainmail Boots',
  );
$itemlist[] = 
  array (
    'item' => 303,
    'name' => 'Chainmail Chestplate',
  );
$itemlist[] = 
  array (
    'item' => 302,
    'name' => 'Chainmail Helmet',
  );
$itemlist[] = 
  array (
    'item' => 304,
    'name' => 'Chainmail Leggings',
  );
$itemlist[] = 
  array (
    'item' => 54,
    'name' => 'Chest',
  );
$itemlist[] = 
  array (
    'item' => 82,
    'name' => 'Clay',
  );
$itemlist[] = 
  array (
    'item' => 337,
    'name' => 'Clay Balls',
  );
$itemlist[] = 
  array (
    'item' => 336,
    'name' => 'Clay Brick',
  );
$itemlist[] = 
  array (
    'item' => 347,
    'name' => 'Clock',
  );
$itemlist[] = 
  array (
    'item' => 263,
    'name' => 'Coal',
  );
$itemlist[] = 
  array (
    'item' => 16,
    'name' => 'Coal ore',
  );
$itemlist[] = 
  array (
    'item' => 4,
    'name' => 'Cobblestone',
  );
$itemlist[] = 
  array (
    'item' => 67,
    'name' => 'Cobblestone Stairs',
  );
$itemlist[] = 
  array (
    'item' => 30,
    'name' => 'Cobweb',
  );
$itemlist[] = 
  array (
    'item' => 345,
    'name' => 'Compass',
  );
$itemlist[] = 
  array (
    'item' => 366,
    'name' => 'Cooked Chicken',
  );
$itemlist[] = 
  array (
    'item' => 350,
    'name' => 'Cooked Fish',
  );
$itemlist[] = 
  array (
    'item' => 320,
    'name' => 'Cooked Porkchop',
  );
$itemlist[] = 
  array (
    'item' => 357,
    'name' => 'Cookie',
  );
$itemlist[] = 
  array (
    'item' => 59,
    'name' => 'Crops',
  );
$itemlist[] = 
  array (
    'item' => 32,
    'name' => 'Dead Shrubs',
  );
$itemlist[] = 
  array (
    'item' => 28,
    'name' => 'Detector Rail',
  );
$itemlist[] = 
  array (
    'item' => 264,
    'name' => 'Diamond',
  );
$itemlist[] = 
  array (
    'item' => 279,
    'name' => 'Diamond Axe',
  );
$itemlist[] = 
  array (
    'item' => 57,
    'name' => 'Diamond Block',
  );
$itemlist[] = 
  array (
    'item' => 313,
    'name' => 'Diamond Boots',
  );
$itemlist[] = 
  array (
    'item' => 311,
    'name' => 'Diamond Chestplate',
  );
$itemlist[] = 
  array (
    'item' => 310,
    'name' => 'Diamond Helmet',
  );
$itemlist[] = 
  array (
    'item' => 293,
    'name' => 'Diamond Hoe',
  );
$itemlist[] = 
  array (
    'item' => 312,
    'name' => 'Diamond Leggings',
  );
$itemlist[] = 
  array (
    'item' => 56,
    'name' => 'Diamond Ore',
  );
$itemlist[] = 
  array (
    'item' => 278,
    'name' => 'Diamond Pickaxe',
  );
$itemlist[] = 
  array (
    'item' => 277,
    'name' => 'Diamond Shovel',
  );
$itemlist[] = 
  array (
    'item' => 276,
    'name' => 'Diamond Sword',
  );
$itemlist[] = 
  array (
    'item' => 3,
    'name' => 'Dirt',
  );
$itemlist[] = 
  array (
    'item' => 2256,
    'name' => 'Disc 13',
  );
$itemlist[] = 
  array (
    'item' => 2257,
    'name' => 'Disc Cat',
  );
$itemlist[] = 
  array (
    'item' => 2258,
    'name' => 'Disc blocks',
  );
$itemlist[] = 
  array (
    'item' => 2259,
    'name' => 'Disc chirp',
  );
$itemlist[] = 
  array (
    'item' => 2260,
    'name' => 'Disc far',
  );
$itemlist[] = 
  array (
    'item' => 2261,
    'name' => 'Disc mall',
  );
$itemlist[] = 
  array (
    'item' => 2262,
    'name' => 'Disc mellohi',
  );
$itemlist[] = 
  array (
    'item' => 2263,
    'name' => 'Disc stal',
  );
$itemlist[] = 
  array (
    'item' => 2264,
    'name' => 'Disc strad',
  );
$itemlist[] = 
  array (
    'item' => 2265,
    'name' => 'Disc ward',
  );
$itemlist[] = 
  array (
    'item' => 2266,
    'name' => 'Disc 11',
  );
$itemlist[] = 
  array (
    'item' => 23,
    'name' => 'Dispenser',
  );
$itemlist[] = 
  array (
    'item' => 43,
    'name' => 'Double Stone Slab',
  );
$itemlist[] = 
  array (
    'item' => 344,
    'name' => 'Egg',
  );
$itemlist[] = 
  array (
    'item' => 116,
    'name' => 'Enchantment Table',
  );
$itemlist[] = 
  array (
    'item' => 119,
    'name' => 'End Portal',
  );
$itemlist[] = 
  array (
    'item' => 120,
    'name' => 'End Portal Frame',
  );
$itemlist[] = 
  array (
    'item' => 368,
    'name' => 'Ender Pearl',
  );
$itemlist[] = 
  array (
    'item' => 381,
    'name' => 'Eye of Ender',
  );
$itemlist[] = 
  array (
    'item' => 60,
    'name' => 'Farmland',
  );
$itemlist[] = 
  array (
    'item' => 288,
    'name' => 'Feather',
  );
$itemlist[] = 
  array (
    'item' => 85,
    'name' => 'Fence',
  );
$itemlist[] = 
  array (
    'item' => 107,
    'name' => 'Fence Gate',
  );
$itemlist[] = 
  array (
    'item' => 376,
    'name' => 'Fermented Spider Eye',
  );
$itemlist[] = 
  array (
    'item' => 51,
    'name' => 'Fire',
  );
$itemlist[] = 
  array (
    'item' => 346,
    'name' => 'Fishing Rod',
  );
$itemlist[] = 
  array (
    'item' => 318,
    'name' => 'Flint',
  );
$itemlist[] = 
  array (
    'item' => 259,
    'name' => 'Flint and Steel',
  );
$itemlist[] = 
  array (
    'item' => 61,
    'name' => 'Furnace',
  );
$itemlist[] = 
  array (
    'item' => 370,
    'name' => 'Ghast Tear',
  );
$itemlist[] = 
  array (
    'item' => 20,
    'name' => 'Glass',
  );
$itemlist[] = 
  array (
    'item' => 374,
    'name' => 'Glass Bottle',
  );
$itemlist[] = 
  array (
    'item' => 102,
    'name' => 'Glass Pane',
  );
$itemlist[] = 
  array (
    'item' => 382,
    'name' => 'Glistering Melon',
  );
$itemlist[] = 
  array (
    'item' => 74,
    'name' => 'Glowing Redstone Ore',
  );
$itemlist[] = 
  array (
    'item' => 89,
    'name' => 'Glowstone',
  );
$itemlist[] = 
  array (
    'item' => 348,
    'name' => 'Glowstone Dust',
  );
$itemlist[] = 
  array (
    'item' => 286,
    'name' => 'Gold Axe',
  );
$itemlist[] = 
  array (
    'item' => 41,
    'name' => 'Gold Block',
  );
$itemlist[] = 
  array (
    'item' => 317,
    'name' => 'Gold Boots',
  );
$itemlist[] = 
  array (
    'item' => 315,
    'name' => 'Gold Chestplate',
  );
$itemlist[] = 
  array (
    'item' => 314,
    'name' => 'Gold Helmet',
  );
$itemlist[] = 
  array (
    'item' => 294,
    'name' => 'Gold Hoe',
  );
$itemlist[] = 
  array (
    'item' => 266,
    'name' => 'Gold Ingot',
  );
$itemlist[] = 
  array (
    'item' => 316,
    'name' => 'Gold Leggings',
  );
$itemlist[] = 
  array (
    'item' => 371,
    'name' => 'Gold Nugget',
  );
$itemlist[] = 
  array (
    'item' => 285,
    'name' => 'Gold Pickaxe',
  );
$itemlist[] = 
  array (
    'item' => 284,
    'name' => 'Gold Shovel',
  );
$itemlist[] = 
  array (
    'item' => 283,
    'name' => 'Gold Sword',
  );
$itemlist[] = 
  array (
    'item' => 14,
    'name' => 'Gold ore',
  );
$itemlist[] = 
  array (
    'item' => 322,
    'name' => 'Golden apple',
  );
$itemlist[] = 
  array (
    'item' => 2,
    'name' => 'Grass',
  );
$itemlist[] = 
  array (
    'item' => 13,
    'name' => 'Gravel',
  );
$itemlist[] = 
  array (
    'item' => 289,
    'name' => 'Gunpowder',
  );
$itemlist[] = 
  array (
    'item' => 99,
    'name' => 'Huge Red Mushroom',
  );
$itemlist[] = 
  array (
    'item' => 100,
    'name' => 'Huge Brown Mushroom',
  );
$itemlist[] = 
  array (
    'item' => 79,
    'name' => 'Ice',
  );
$itemlist[] = 
  array (
    'item' => 351,
    'name' => 'Ink Sac',
  );
$itemlist[] = 
  array (
    'item' => 258,
    'name' => 'Iron Axe',
  );
$itemlist[] = 
  array (
    'item' => 101,
    'name' => 'Iron Bars',
  );
$itemlist[] = 
  array (
    'item' => 42,
    'name' => 'Iron Block',
  );
$itemlist[] = 
  array (
    'item' => 309,
    'name' => 'Iron Boots',
  );
$itemlist[] = 
  array (
    'item' => 307,
    'name' => 'Iron Chestplate',
  );
$itemlist[] = 
  array (
    'item' => 71,
    'name' => 'Iron Door',
  );
$itemlist[] = 
  array (
    'item' => 306,
    'name' => 'Iron Helmet',
  );
$itemlist[] = 
  array (
    'item' => 292,
    'name' => 'Iron Hoe',
  );
$itemlist[] = 
  array (
    'item' => 265,
    'name' => 'Iron Ingot',
  );
$itemlist[] = 
  array (
    'item' => 308,
    'name' => 'Iron Leggings',
  );
$itemlist[] = 
  array (
    'item' => 257,
    'name' => 'Iron Pickaxe',
  );
$itemlist[] = 
  array (
    'item' => 256,
    'name' => 'Iron Shovel',
  );
$itemlist[] = 
  array (
    'item' => 267,
    'name' => 'Iron Sword',
  );
$itemlist[] = 
  array (
    'item' => 330,
    'name' => 'Iron door',
  );
$itemlist[] = 
  array (
    'item' => 15,
    'name' => 'Iron ore',
  );
$itemlist[] = 
  array (
    'item' => 91,
    'name' => 'Jack-O-Lantern',
  );
$itemlist[] = 
  array (
    'item' => 84,
    'name' => 'Jukebox',
  );
$itemlist[] = 
  array (
    'item' => 65,
    'name' => 'Ladder',
  );
$itemlist[] = 
  array (
    'item' => 22,
    'name' => 'Lapis Lazuli Block',
  );
$itemlist[] = 
  array (
    'item' => 21,
    'name' => 'Lapis Lazuli Ore',
  );
$itemlist[] = 
  array (
    'item' => 10,
    'name' => 'Lava',
  );
$itemlist[] = 
  array (
    'item' => 327,
    'name' => 'Lava bucket',
  );
$itemlist[] = 
  array (
    'item' => 334,
    'name' => 'Leather',
  );
$itemlist[] = 
  array (
    'item' => 301,
    'name' => 'Leather Boots',
  );
$itemlist[] = 
  array (
    'item' => 299,
    'name' => 'Leather Chestplate',
  );
$itemlist[] = 
  array (
    'item' => 298,
    'name' => 'Leather Helmet',
  );
$itemlist[] = 
  array (
    'item' => 300,
    'name' => 'Leather Leggings',
  );
$itemlist[] = 
  array (
    'item' => 18,
    'name' => 'Leaves',
  );
$itemlist[] = 
  array (
    'item' => 69,
    'name' => 'Lever',
  );
$itemlist[] = 
  array (
    'item' => 111,
    'name' => 'Lily Pad',
  );
$itemlist[] = 
  array (
    'item' => 95,
    'name' => 'Locked Chest',
  );
$itemlist[] = 
  array (
    'item' => 358,
    'name' => 'Map',
  );
$itemlist[] = 
  array (
    'item' => 378,
    'name' => 'Magma Cream',
  );
$itemlist[] = 
  array (
    'item' => 103,
    'name' => 'Melon',
  );
$itemlist[] = 
  array (
    'item' => 360,
    'name' => 'Melon (Slice)',
  );
$itemlist[] = 
  array (
    'item' => 361,
    'name' => 'Melon Seeds',
  );
$itemlist[] = 
  array (
    'item' => 105,
    'name' => 'Melon Stem',
  );
$itemlist[] = 
  array (
    'item' => 335,
    'name' => 'Milk',
  );
$itemlist[] = 
  array (
    'item' => 328,
    'name' => 'Minecart',
  );
$itemlist[] = 
  array (
    'item' => 66,
    'name' => 'Minecart Tracks',
  );
$itemlist[] = 
  array (
    'item' => 52,
    'name' => 'Monster Spawner',
  );
$itemlist[] = 
  array (
    'item' => 48,
    'name' => 'Moss Stone',
  );
$itemlist[] = 
  array (
    'item' => 282,
    'name' => 'Mushroom Soup',
  );
$itemlist[] = 
  array (
    'item' => 110,
    'name' => 'Mycelium',
  );
$itemlist[] = 
  array (
    'item' => 112,
    'name' => 'Nether Brick',
  );
$itemlist[] = 
  array (
    'item' => 113,
    'name' => 'Nether Brick Fence',
  );
$itemlist[] = 
  array (
    'item' => 114,
    'name' => 'Nether Brick Stairs',
  );
$itemlist[] = 
  array (
    'item' => 372,
    'name' => 'Nether Wart',
  );
$itemlist[] = 
  array (
    'item' => 87,
    'name' => 'Netherrack',
  );
$itemlist[] = 
  array (
    'item' => 25,
    'name' => 'Note Block',
  );
$itemlist[] = 
  array (
    'item' => 49,
    'name' => 'Obsidian',
  );
$itemlist[] = 
  array (
    'item' => 321,
    'name' => 'Paintings',
  );
$itemlist[] = 
  array (
    'item' => 339,
    'name' => 'Paper',
  );
$itemlist[] = 
  array (
    'item' => 33,
    'name' => 'Piston',
  );
$itemlist[] = 
  array (
    'item' => 90,
    'name' => 'Portal',
  );
$itemlist[] = 
  array (
    'item' => 373,
    'name' => 'Potions',
  );
$itemlist[] = 
  array (
    'item' => 343,
    'name' => 'Powered Minecart',
  );
$itemlist[] = 
  array (
    'item' => 27,
    'name' => 'Powered Rail',
  );
$itemlist[] = 
  array (
    'item' => 86,
    'name' => 'Pumpkin',
  );
$itemlist[] = 
  array (
    'item' => 361,
    'name' => 'Pumpkin Seeds',
  );
$itemlist[] = 
  array (
    'item' => 104,
    'name' => 'Pumpkin Stem',
  );
$itemlist[] = 
  array (
    'item' => 66,
    'name' => 'Rails',
  );
$itemlist[] = 
  array (
    'item' => 363,
    'name' => 'Raw Beef',
  );
$itemlist[] = 
  array (
    'item' => 365,
    'name' => 'Raw Chicken',
  );
$itemlist[] = 
  array (
    'item' => 349,
    'name' => 'Raw Fish',
  );
$itemlist[] = 
  array (
    'item' => 319,
    'name' => 'Raw Porkchop',
  );
$itemlist[] = 
  array (
    'item' => 40,
    'name' => 'Red Mushroom',
  );
$itemlist[] = 
  array (
    'item' => 38,
    'name' => 'Red rose',
  );
$itemlist[] = 
  array (
    'item' => 331,
    'name' => 'Redstone',
  );
$itemlist[] = 
  array (
    'item' => 73,
    'name' => 'Redstone Ore',
  );
$itemlist[] = 
  array (
    'item' => 55,
    'name' => 'Redstone Wire',
  );
$itemlist[] = 
  array (
    'item' => 356,
    'name' => 'Redstone Repeater',
  );
$itemlist[] = 
  array (
    'item' => 75,
    'name' => 'Redstone torch OFF',
  );
$itemlist[] = 
  array (
    'item' => 76,
    'name' => 'Redstone torch ON',
  );
$itemlist[] = 
  array (
    'item' => 367,
    'name' => 'Rotten Flesh',
  );
$itemlist[] = 
  array (
    'item' => 329,
    'name' => 'Saddle',
  );
$itemlist[] = 
  array (
    'item' => 12,
    'name' => 'Sand',
  );
$itemlist[] = 
  array (
    'item' => 24,
    'name' => 'Sandstone',
  );
$itemlist[] = 
  array (
    'item' => 6,
    'name' => 'Sapling',
  );
$itemlist[] = 
  array (
    'item' => 295,
    'name' => 'Seeds',
  );
$itemlist[] = 
  array (
    'item' => 359,
    'name' => 'Shears',
  );
$itemlist[] = 
  array (
    'item' => 323,
    'name' => 'Sign',
  );
$itemlist[] = 
  array (
    'item' => 63,
    'name' => 'Sign Post',
  );
$itemlist[] = 
  array (
    'item' => 341,
    'name' => 'Slimeball',
  );
$itemlist[] = 
  array (
    'item' => 78,
    'name' => 'Snow',
  );
$itemlist[] = 
  array (
    'item' => 80,
    'name' => 'Snow Block',
  );
$itemlist[] = 
  array (
    'item' => 332,
    'name' => 'Snowball',
  );
$itemlist[] = 
  array (
    'item' => 88,
    'name' => 'Soul Sand',
  );
$itemlist[] = 
  array (
    'item' => 375,
    'name' => 'Spider Eye',
  );
$itemlist[] = 
  array (
    'item' => 19,
    'name' => 'Sponge',
  );
$itemlist[] = 
  array (
    'item' => 11,
    'name' => 'Stationary lava',
  );
$itemlist[] = 
  array (
    'item' => 9,
    'name' => 'Stationary water',
  );
$itemlist[] = 
  array (
    'item' => 364,
    'name' => 'Steak',
  );
$itemlist[] = 
  array (
    'item' => 280,
    'name' => 'Stick',
  );
$itemlist[] = 
  array (
    'item' => 29,
    'name' => 'Sticky Piston',
  );
$itemlist[] = 
  array (
    'item' => 1,
    'name' => 'Stone',
  );
$itemlist[] = 
  array (
    'item' => 275,
    'name' => 'Stone Axe',
  );
$itemlist[] = 
  array (
    'item' => 109,
    'name' => 'Stone Brick Stairs',
  );
$itemlist[] = 
  array (
    'item' => 77,
    'name' => 'Stone Button',
  );
$itemlist[] = 
  array (
    'item' => 291,
    'name' => 'Stone Hoe',
  );
$itemlist[] = 
  array (
    'item' => 274,
    'name' => 'Stone Pickaxe',
  );
$itemlist[] = 
  array (
    'item' => 70,
    'name' => 'Stone Pressure Plate',
  );
$itemlist[] = 
  array (
    'item' => 273,
    'name' => 'Stone Shovel',
  );
$itemlist[] = 
  array (
    'item' => 44,
    'name' => 'Stone Slab',
  );
$itemlist[] = 
  array (
    'item' => 272,
    'name' => 'Stone Sword',
  );
$itemlist[] = 
  array (
    'item' => 342,
    'name' => 'Storage Minecart',
  );
$itemlist[] = 
  array (
    'item' => 287,
    'name' => 'String',
  );
$itemlist[] = 
  array (
    'item' => 353,
    'name' => 'Sugar',
  );
$itemlist[] = 
  array (
    'item' => 338,
    'name' => 'Sugar Cane',
  );
$itemlist[] = 
  array (
    'item' => 83,
    'name' => 'Sugar Cane',
  );
$itemlist[] = 
  array (
    'item' => 31,
    'name' => 'Tall Grass',
  );
$itemlist[] = 
  array (
    'item' => 46,
    'name' => 'TNT',
  );
$itemlist[] = 
  array (
    'item' => 50,
    'name' => 'Torch ',
  );
$itemlist[] = 
  array (
    'item' => 96,
    'name' => 'Trapdoor',
  );
$itemlist[] = 
  array (
    'item' => 106,
    'name' => 'Vines',
  );
$itemlist[] = 
  array (
    'item' => 68,
    'name' => 'Wall Sign',
  );
$itemlist[] = 
  array (
    'item' => 8,
    'name' => 'Water',
  );
$itemlist[] = 
  array (
    'item' => 326,
    'name' => 'Water bucket',
  );
$itemlist[] = 
  array (
    'item' => 296,
    'name' => 'Wheat',
  );
$itemlist[] = 
  array (
    'item' => 121,
    'name' => 'White Stone',
  );
$itemlist[] = 
  array (
    'item' => 17,
    'name' => 'Wood',
  );
$itemlist[] = 
  array (
    'item' => 271,
    'name' => 'Wooden Axe',
  );
$itemlist[] = 
  array (
    'item' => 64,
    'name' => 'Wooden Door',
  );
$itemlist[] = 
  array (
    'item' => 290,
    'name' => 'Wooden Hoe',
  );
$itemlist[] = 
  array (
    'item' => 270,
    'name' => 'Wooden Pickaxe',
  );
$itemlist[] = 
  array (
    'item' => 5,
    'name' => 'Wooden Plank',
  );
$itemlist[] = 
  array (
    'item' => 72,
    'name' => 'Wooden Pressure Plate',
  );
$itemlist[] = 
  array (
    'item' => 269,
    'name' => 'Wooden Shovel',
  );
$itemlist[] = 
  array (
    'item' => 53,
    'name' => 'Wooden Stairs',
  );
$itemlist[] = 
  array (
    'item' => 268,
    'name' => 'Wooden Sword',
  );
$itemlist[] = 
  array (
    'item' => 324,
    'name' => 'Wooden door',
  );
$itemlist[] = 
  array (
    'item' => 35,
    'name' => 'Wool',
  );
$itemlist[] = 
  array (
    'item' => 58,
    'name' => 'Workbench',
  );
$itemlist[] = 
  array (
    'item' => 37,
    'name' => 'Yellow flower',
  );

