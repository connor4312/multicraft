<?php include dirname(__FILE__).'/../daemon/status.php';
