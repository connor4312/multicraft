<?php include dirname(__FILE__).'/../daemon/_statusBox.php';
