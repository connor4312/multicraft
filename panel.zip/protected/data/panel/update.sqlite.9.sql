create unique index `name` on `user` (`name`);
create unique index `email` on `user` (`email`);

