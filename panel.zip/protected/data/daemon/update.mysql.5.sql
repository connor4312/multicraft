alter table `server` add `suspended` integer not null default 0;
