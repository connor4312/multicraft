<?php

return array('short'=>'de', 'english'=>'German', 'local'=>'Deutsch');
